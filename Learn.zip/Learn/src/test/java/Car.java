public class Car extends ForAbstrct{

    @org.testng.annotations.Test
    @Override
    void startVehical() {
        System.out.println("car starts with key");
    }
}
