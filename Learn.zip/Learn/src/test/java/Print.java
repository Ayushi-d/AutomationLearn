public class Print {

         public static String Hello = "Hello";
         public static String Doing = "Doing";
         public static String Inheritance = "Inheritance";
         public static String Practise = "Practise";
    }

