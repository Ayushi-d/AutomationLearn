public class Scooter extends ForAbstrct {

    @Override
    void startVehical() {
        System.out.println("Scooter starts with kick");
    }
}
