public abstract class ForAbstrct {
    abstract void startVehical();
}
