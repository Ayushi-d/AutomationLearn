public interface Chair {
    void sittingOnChair();
}
