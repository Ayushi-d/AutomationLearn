 class HelloPrint {

    public String myName(){
        String hello = "My name";
        return hello;
    }
}
