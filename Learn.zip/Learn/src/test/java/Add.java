import org.testng.annotations.Test;


//this is class
public class Add  extends Print{

    String A= "hello sir";
    Model model = new Model();

    //creating meathod
    @Test
    void sum(){
        System.out.println(A);
    }

    //Inheritance
    @Test
    void print(){
        String hello = Hello;
        System.out.println(hello);
    }

    //calling by creating obj
   @Test
    void gettoken(){
        CallObj callOb = new CallObj();
        String token = callOb.ttoken();
        int gettingtoken = callOb.token();
        System.out.println(token);
        System.out.println(gettingtoken);
   }
   //encapsulate
   @Test
    void setname(){
       model.setName("learning encapsulation");
       System.out.println(model.getName());
   }
  
}
