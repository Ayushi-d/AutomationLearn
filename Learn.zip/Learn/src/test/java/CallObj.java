import java.security.PublicKey;

public class CallObj {


    public String ttoken(){
        String token = "34ldsnsd9u39u53jwfsdfjosd";
        return token;
    }

    public int token(){
        int token = 1234567890;
        return token;
    }
}
