import org.testng.annotations.Test;

public class Name extends HelloPrint{

    //overring
    public void overRide(){
        HelloPrint helloPrint= new HelloPrint();
        helloPrint.myName();
    }

    //eg overloading
    public int overload(int a, int b){
        return(a+b);
    }
    public double overload(Double a , Double b,Double c){

        return(a+b+c);
    }

    @Test
    public void answer(){
        Name name= new Name();
        name.overload(10,20);
        name.overload(0.10,0.20,0.30);
    }


}
