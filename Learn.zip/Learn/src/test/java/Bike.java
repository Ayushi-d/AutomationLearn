import org.testng.annotations.Test;

public class Bike implements Vehical , Chair{

    @Test
    @Override
    public void helloWord() {
        System.out.println("hahahahahahah");
    }

    @Override
    public void sittingOnChair() {

    }
}
