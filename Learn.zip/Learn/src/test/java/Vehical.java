public interface Vehical {

     void helloWord();
}
